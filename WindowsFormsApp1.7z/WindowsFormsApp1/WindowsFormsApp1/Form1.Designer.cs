﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Deck = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Discard = new System.Windows.Forms.PictureBox();
            this.hand2 = new System.Windows.Forms.PictureBox();
            this.hand1 = new System.Windows.Forms.PictureBox();
            this.hand4 = new System.Windows.Forms.PictureBox();
            this.hand3 = new System.Windows.Forms.PictureBox();
            this.hand6 = new System.Windows.Forms.PictureBox();
            this.hand5 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Deck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Discard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand5)).BeginInit();
            this.SuspendLayout();
            // 
            // Deck
            // 
            this.Deck.Location = new System.Drawing.Point(12, 34);
            this.Deck.Name = "Deck";
            this.Deck.Size = new System.Drawing.Size(99, 153);
            this.Deck.TabIndex = 0;
            this.Deck.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(298, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Opponent\'s turn";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Discard
            // 
            this.Discard.Location = new System.Drawing.Point(133, 34);
            this.Discard.Name = "Discard";
            this.Discard.Size = new System.Drawing.Size(99, 153);
            this.Discard.TabIndex = 2;
            this.Discard.TabStop = false;
            // 
            // hand2
            // 
            this.hand2.Location = new System.Drawing.Point(133, 297);
            this.hand2.Name = "hand2";
            this.hand2.Size = new System.Drawing.Size(99, 153);
            this.hand2.TabIndex = 4;
            this.hand2.TabStop = false;
            // 
            // hand1
            // 
            this.hand1.Location = new System.Drawing.Point(12, 297);
            this.hand1.Name = "hand1";
            this.hand1.Size = new System.Drawing.Size(99, 153);
            this.hand1.TabIndex = 3;
            this.hand1.TabStop = false;
            // 
            // hand4
            // 
            this.hand4.Location = new System.Drawing.Point(382, 297);
            this.hand4.Name = "hand4";
            this.hand4.Size = new System.Drawing.Size(99, 153);
            this.hand4.TabIndex = 6;
            this.hand4.TabStop = false;
            // 
            // hand3
            // 
            this.hand3.Location = new System.Drawing.Point(261, 297);
            this.hand3.Name = "hand3";
            this.hand3.Size = new System.Drawing.Size(99, 153);
            this.hand3.TabIndex = 5;
            this.hand3.TabStop = false;
            // 
            // hand6
            // 
            this.hand6.Location = new System.Drawing.Point(631, 297);
            this.hand6.Name = "hand6";
            this.hand6.Size = new System.Drawing.Size(99, 153);
            this.hand6.TabIndex = 8;
            this.hand6.TabStop = false;
            // 
            // hand5
            // 
            this.hand5.Location = new System.Drawing.Point(510, 297);
            this.hand5.Name = "hand5";
            this.hand5.Size = new System.Drawing.Size(99, 153);
            this.hand5.TabIndex = 7;
            this.hand5.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Your hand";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Oponent";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(153, 190);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Discard";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 585);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.hand6);
            this.Controls.Add(this.hand5);
            this.Controls.Add(this.hand4);
            this.Controls.Add(this.hand3);
            this.Controls.Add(this.hand2);
            this.Controls.Add(this.hand1);
            this.Controls.Add(this.Discard);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Deck);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Deck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Discard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hand5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Deck;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox Discard;
        private System.Windows.Forms.PictureBox hand2;
        private System.Windows.Forms.PictureBox hand1;
        private System.Windows.Forms.PictureBox hand4;
        private System.Windows.Forms.PictureBox hand3;
        private System.Windows.Forms.PictureBox hand6;
        private System.Windows.Forms.PictureBox hand5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

