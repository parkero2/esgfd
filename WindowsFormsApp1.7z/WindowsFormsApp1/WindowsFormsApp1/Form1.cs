﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class card
    {
        public card(string cardName)
        {
            string name = cardName;
            string path = "../../assets/" + name;
            string color = name.Substring(0, name.IndexOf("_"));
            try
            {
                int value = int.Parse(name.Substring(name.IndexOf("_"), name.IndexOf("_") + 1));
            }
            catch
            {
                string action = name.Substring(name.IndexOf("_") + 1, name.Length - 1).Substring(0, name.IndexOf("_"));
            }
        }
    }
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Deck.Image = Image.FromFile("../../assets/card_back_large.png");
            Deck.SizeMode = PictureBoxSizeMode.StretchImage;
            Discard.SizeMode = PictureBoxSizeMode.StretchImage;
            Discard.Image = Image.FromFile(genreateDeck());
            card[] playercards = { };
            string[] illegal_cards = { "card_back_alt_large.png", "card_back_large.png" };
            for (int i = 0; i < 6; i++)
            {
                string card1 = genreateDeck();
                while (illegal_cards.Contains(card1))
                {
                    card1 = genreateDeck();
                }
                playercards.Append(new card(card1));
            }
        }

        public string genreateDeck()
        {
            string dir = "../../assets";
            FileInfo[] file = new DirectoryInfo(dir).GetFiles();
            Random random = new Random();
            int index = random.Next(file.Length);
            System.Console.WriteLine(file[index].Name);
            return file[index].Name; 
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
